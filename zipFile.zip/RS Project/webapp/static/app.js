const $ = (sel) => document.querySelector(sel);

function setStatus(ok, text){
  const dot = $("#statusDot");
  dot.classList.remove("ok","bad");
  dot.classList.add(ok ? "ok" : "bad");
  $("#statusText").textContent = text;
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
}

async function apiGet(path){
  const r = await fetch(path, { headers: { "Accept":"application/json" }});
  const data = await r.json().catch(() => ({}));
  if(!r.ok) throw new Error(data?.error || `Request failed (${r.status})`);
  return data;
}

async function apiPost(path, payload){
  const r = await fetch(path, {
    method: "POST",
    headers: { "Content-Type":"application/json", "Accept":"application/json" },
    body: JSON.stringify(payload),
  });
  const data = await r.json().catch(() => ({}));
  if(!r.ok) throw new Error(data?.error || `Request failed (${r.status})`);
  return data;
}

let MOVIES = [];
let METHOD = "content";
let SEED = null;
let SELECTED_GENRES = new Set();

function posterStyle(poster){
  const hue = poster?.hue ?? 12;
  return `background: linear-gradient(135deg, hsla(${hue}, 85%, 54%, .55), rgba(255,255,255,.10));`;
}

function posterSvgDataUri(movie){
  // Always-available "poster" (no API keys): SVG with gradient + title/year/rating.
  const hue = movie?.poster?.hue ?? ((Number(movie?.movieId || 1) * 47) % 360);
  const title = String(movie?.title || "Movify").slice(0, 42);
  const year = movie?.year ?? "—";
  const rating = (movie?.rating ?? "N/A");
  const genres = (movie?.genres || []).slice(0, 2).join(" • ");

  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" width="340" height="480" viewBox="0 0 340 480">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="hsl(${hue},85%,52%)" stop-opacity="0.85"/>
        <stop offset="0.55" stop-color="#111" stop-opacity="0.55"/>
        <stop offset="1" stop-color="#000" stop-opacity="0.95"/>
      </linearGradient>
      <radialGradient id="r" cx="35%" cy="20%" r="80%">
        <stop offset="0" stop-color="rgba(255,255,255,0.18)"/>
        <stop offset="1" stop-color="rgba(255,255,255,0)"/>
      </radialGradient>
    </defs>
    <rect width="340" height="480" fill="url(#g)"/>
    <rect width="340" height="480" fill="url(#r)"/>
    <rect x="18" y="18" width="72" height="30" rx="10" fill="rgba(229,9,20,0.85)"/>
    <text x="54" y="39" text-anchor="middle" font-family="Arial, sans-serif" font-size="14" font-weight="800" fill="#fff">Movify</text>

    <text x="22" y="360" font-family="Arial, sans-serif" font-size="22" font-weight="900" fill="#fff">${escapeHtml(title)}</text>
    <text x="22" y="388" font-family="Arial, sans-serif" font-size="14" font-weight="700" fill="rgba(255,255,255,0.85)">${escapeHtml(String(year))} • ⭐ ${escapeHtml(String(rating))}</text>
    <text x="22" y="414" font-family="Arial, sans-serif" font-size="12" font-weight="600" fill="rgba(255,255,255,0.70)">${escapeHtml(genres)}</text>
    <text x="22" y="452" font-family="Arial, sans-serif" font-size="11" fill="rgba(255,255,255,0.60)">IMDB Top 250 • Explainable</text>
  </svg>`;

  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg.trim());
}

function renderCard(movie, { onClick } = {}){
  const title = escapeHtml(movie.title);
  const yr = movie.year ?? "—";
  const rating = (movie.rating ?? 0).toFixed ? movie.rating.toFixed(1) : movie.rating;
  const genres = (movie.genres || []).slice(0,2).join(" • ");
  const why = movie.explanation ? buildWhy(movie.explanation) : "";
  const whyHtml = why ? `<div class="whyBox">${why}</div>` : "";
  const bg = posterSvgDataUri(movie);
  return `
    <div class="cardMovie" data-id="${movie.movieId}">
      <div class="poster" style="${posterStyle(movie.poster)} background-image: url('${bg}'); background-size: cover; background-position: center;">
        <div class="poster__title">${title}</div>
      </div>
      <div class="cardMovie__meta">
        <div class="pillMini"><b>${escapeHtml(String(yr))}</b> • ⭐ ${escapeHtml(String(rating ?? "N/A"))}</div>
        <div class="muted" style="font-size:12px;">${escapeHtml(genres || " ")}</div>
        ${whyHtml}
      </div>
    </div>
  `;
}

function buildWhy(expl){
  if(!expl) return "";
  if(expl.type === "content"){
    const terms = (expl.top_terms || []).slice(0,6);
    if(terms.length){
      return `<b>Why:</b> shared terms: ${escapeHtml(terms.join(", "))}`;
    }
    return `<b>Why:</b> ${escapeHtml(expl.why || "Similar content features.")}`;
  }
  if(expl.type === "collaborative"){
    return `<b>Why:</b> ${escapeHtml(expl.why || "Similar co-preference pattern (item-based).")}`;
  }
  return `<b>Why:</b> ${escapeHtml(expl.why || "Explainable recommendation.")}`;
}

function setMethod(m){
  METHOD = m;
  $("#methodContent").classList.toggle("chip--on", METHOD === "content");
  $("#methodCollab").classList.toggle("chip--on", METHOD === "collaborative");
  $("#compareLabel").textContent = METHOD === "content"
    ? "Collaborative Filtering Results (Comparison)"
    : "Content‑Based Filtering Results (Comparison)";
}

function setSeed(movie){
  SEED = movie;
  $("#seedTitle").textContent = movie ? movie.title : "Select a movie card";
  $("#seedSub").textContent = movie ? `Year ${movie.year ?? "—"} • ⭐ ${movie.rating ?? "N/A"}` : "Then we’ll recommend similar titles.";
  $("#seedPoster").setAttribute("style", movie ? posterStyle(movie.poster) : "");
  $("#recommendBtn").disabled = !movie;
}

function railMount(railEl, movies, clickHandler){
  railEl.innerHTML = movies.map(m => renderCard(m)).join("");
  railEl.querySelectorAll(".cardMovie").forEach(el => {
    el.addEventListener("click", () => {
      const id = Number(el.getAttribute("data-id"));
      const movie = movies.find(x => x.movieId === id) || MOVIES.find(x => x.movieId === id);
      if(movie && clickHandler) clickHandler(movie);
    });
  });
}

async function loadFeatured(){
  const data = await apiGet("/api/featured");
  const f = data.featured;
  if(!f) return;
  $("#heroTitle").textContent = f.title;
  $("#heroTagline").textContent = f.tagline || "Pick a movie and compare content-based vs collaborative recommendations.";
  $("#heroBg").setAttribute("style", posterStyle(f.poster));
}

async function loadGenres(){
  const data = await apiGet("/api/genres");
  const genres = data.genres || [];
  const box = $("#genreChips");
  box.innerHTML = "";
  for(const g of genres){
    const b = document.createElement("button");
    b.className = "chip";
    b.textContent = g;
    b.addEventListener("click", () => {
      if(SELECTED_GENRES.has(g)) SELECTED_GENRES.delete(g); else SELECTED_GENRES.add(g);
      b.classList.toggle("chip--on", SELECTED_GENRES.has(g));
    });
    box.appendChild(b);
  }
}

async function loadTop(){
  const data = await apiGet("/api/movies?limit=40");
  MOVIES = data.results || [];
  railMount($("#railTop"), MOVIES, (m) => setSeed(m));
}

async function searchMovies(q){
  const data = await apiGet(`/api/movies?q=${encodeURIComponent(q)}&limit=40`);
  const results = data.results || [];
  railMount($("#railTop"), results, (m) => setSeed(m));
}

async function recommendFromSeed(){
  $("#recErr").textContent = "";
  if(!SEED) return;
  const payload = { method: METHOD, seed_movieId: SEED.movieId, n: 12 };
  try{
    const data = await apiPost("/api/recommend", payload);
    railMount($("#railPrimary"), data.primary || [], (m) => setSeed(m));
    railMount($("#railComparison"), data.comparison || [], (m) => setSeed(m));
    document.querySelector("#recommend")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }catch(e){
    $("#recErr").textContent = e?.message || String(e);
  }
}

async function recommendColdStart(){
  $("#recErr").textContent = "";
  const coldErr = $("#coldErr");
  if(coldErr) coldErr.textContent = "";
  const preferred_genres = Array.from(SELECTED_GENRES);
  if(preferred_genres.length === 0){
    const msg = "Select at least 1 genre for cold start.";
    $("#recErr").textContent = msg;
    if(coldErr) coldErr.textContent = msg;
    return;
  }
  const payload = { method: METHOD, preferred_genres, liked_movieIds: [], n: 12 };
  try{
    const data = await apiPost("/api/recommend", payload);
    railMount($("#railPrimary"), data.primary || [], (m) => setSeed(m));
    railMount($("#railComparison"), data.comparison || [], (m) => setSeed(m));
    document.querySelector("#recommend")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }catch(e){
    const msg = e?.message || String(e);
    $("#recErr").textContent = msg;
    if(coldErr) coldErr.textContent = msg;
  }
}

async function boot(){
  try{
    const h = await apiGet("/api/health");
    setStatus(true, `Online • ${h.movies} movies • ${h.genres} genres`);
    setMethod("content");
    await loadFeatured();
    await loadGenres();
    await loadTop();
  }catch(e){
    setStatus(false, `Offline • ${e.message}`);
  }
}

$("#methodContent").addEventListener("click", () => setMethod("content"));
$("#methodCollab").addEventListener("click", () => setMethod("collaborative"));

$("#searchBtn").addEventListener("click", async () => {
  const q = $("#searchInput").value.trim();
  if(!q) return loadTop();
  await searchMovies(q);
});

$("#recommendBtn").addEventListener("click", recommendFromSeed);
$("#coldStartBtn").addEventListener("click", recommendColdStart);

boot();

